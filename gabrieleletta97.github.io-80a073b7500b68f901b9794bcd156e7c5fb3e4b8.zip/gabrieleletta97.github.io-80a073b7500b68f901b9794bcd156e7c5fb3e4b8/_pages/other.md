---
layout: default
title: "Other"
permalink: /other/
author_profile: true
---

<div class="content-center">
  <div class="quote-container">
    <div class="quote">
      <blockquote>
        <p>
          "It's life that matters, nothing but life — the process of discovering, the everlasting and perpetual process, not the discovery itself, at all." - FD
        </p>
      </blockquote>
    </div>
  </div>  



  <div class="image-container">
    <img src="https://gabrieleletta97.github.io/images/idiotic.jpeg" alt="[Friend's Name] photo or a symbolic image" style="max-width: 75%; height: auto;">
  </div>
</div>
