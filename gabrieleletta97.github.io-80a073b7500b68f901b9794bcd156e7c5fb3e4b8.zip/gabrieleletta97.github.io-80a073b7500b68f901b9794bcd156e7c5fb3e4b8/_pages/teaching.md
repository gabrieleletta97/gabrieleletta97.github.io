---
layout: archive
title: "Teaching"
permalink: /teaching/
author_profile: true
classes: teaching-page
---
**Policy Evaluation - Macroeconometrics Tutorial** <br>
MsC in Economics  <br>
Università Cattolica del Sacro Cuore, Milan, Italy - Department of Economics and Finance <br>
*2023*

**Policy Evaluation - Macroeconometrics Tutorial** <br>
MsC in Economics  <br>
Università Cattolica del Sacro Cuore, Milan, Italy - Department of Economics and Finance <br>
*2022*

**Student tutorials - International Economics; Economic Policy** <br>
BSc in Scienze Economiche - Economics <br>
Sapienza University of Rome, Italy - Department of Economics and Law  <br>
*2021*

