---
title: "Student tutorials - International Economics; Economic Policy<br>
(BSc in Scienze Economiche - Economics)"
collection: teaching
course_type: "Undergraduate course"  # Changed from 'type'
language: "Italian"
permalink: /teaching/1-tutoring
venue: "Sapienza University of Rome, Italy - Department of Economics and Law"
date: 2021-01-01
location: "Rome, Italy"
---
