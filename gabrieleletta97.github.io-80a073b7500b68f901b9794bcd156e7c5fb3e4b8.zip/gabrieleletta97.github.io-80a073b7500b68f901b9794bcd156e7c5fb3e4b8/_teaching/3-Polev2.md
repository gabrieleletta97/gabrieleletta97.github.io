---
title: "Policy Evaluation - Macroeconometrics Tutorial<br>(MSc in Economics)"
collection: teaching
course_type: "Master's degree course"  # Changed from 'type'
language: "English"
permalink: /teaching/3-Polev2
venue: "Università Cattolica del Sacro Cuore, Milan, Italy - Department of Economics and Finance"
date: 2023-01-01
location: "Milan, Italy"
---


