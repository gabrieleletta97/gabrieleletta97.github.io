---
title: "Policy Evaluation - Macroeconometrics Tutorial<br>(MSc in Economics)"
collection: teaching
course_type: "Master's degree course"  # Changed from 'type'
language: "English"
permalink: /teaching/2-Polev1
venue: "Università Cattolica del Sacro Cuore, Milan, Italy - Department of Economics and Finance"
date: 2022-01-01
location: "Milan, Italy"
---


